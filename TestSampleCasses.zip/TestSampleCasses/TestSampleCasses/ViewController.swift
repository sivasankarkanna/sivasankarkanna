//
//  ViewController.swift
//  TestSampleCasses
//
//  Created by Apple on 10/03/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import UIKit
import MastercardSonic
import VisionKit

class ViewController: UIViewController {
    @IBOutlet weak var uitextFielsSample: UITextField!
    
    private let sonicManager: MCSonicController = MCSonicController()
    @IBOutlet private weak var mcSonicView: MCSonicView!
    @IBOutlet weak var calenderImg: UIImageView!
    var visa_Timer: Timer? = nil
    @IBOutlet weak var urlImageView: UIImageView!
    var currentTime: Date?
    var ninteenDaysfromNow: Date {   // Get date for Next 90 dayes from current date
        return (Calendar.current as NSCalendar).date(byAdding: .day, value: 90, to: Date(), options: [])!
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    @IBAction func cameraButtonAction(_ sender: Any) {
    }
    
    fileprivate func mainThred() {
        DispatchQueue.main.async {
           // self.uitextFielsSample.text = "sample test"
            print("self.uitextFielsSample.text ?? ")
        }
       // self.dispachQuee()
    }
    
    func dispachQuee() {
         DispatchQueue.main.async {
              //self.uitextFielsSample.text = "sample test"
              print("self.uitextFielsSample.text ??")
          }
    }
    
    func updateTime() {
      currentTime = Date()
      let formatter = DateFormatter()
      formatter.timeStyle = .short

      if let currentTime = currentTime {
        print(formatter.string(from: currentTime)) 
      }
    }
    
    @objc func fireTimer() {
        
        sonicManager.prepare(with: .animationAndSound, completion: { (status) in
            print("Status1 = \(status.rawValue)")
            self.mcSonicView.isHidden = false
            self.playSonic()
        })
    }

    func playSonic() {
        if(!sonicManager.isPlaying) {
            sonicManager.play(with: self.mcSonicView, completion: { (status) in
                print("Status2 = \(status.rawValue)")
                self.visa_Timer?.invalidate()
                self.visa_Timer = nil
            })
        }
    }
}

extension UIImageView {
    func load(url: URL) {
        DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: url) {
                let uiimahe1 = UIImage()
                if let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self?.image = image
                    }
                }
            }
        }
    }
}



enum FillingTypeString:String {
    
    case individual = "Individual"
    case solo = "Sole"
    case partnership = "Partnership"
    case Private = "Private"
    case Public = "Public"
    case llp = "LLP"
    case society = "Society"
    case trust = "Trust"
    
    var checkFillingTypeAPI:String {
        
        switch self {
            
        case .individual:
            return "Individual"
        case .solo:
            return "Sole Proprietorship"
        case .partnership:
            return "Partnership"
        case .Private:
            return "Private Limited Company"
        case .Public:
            return "Public Limited Company"
        case .llp:
            return "Limited Liability Partnership"
        case .society:
            return "Society"
        case .trust:
            return "Trust"
        }
    }
}

