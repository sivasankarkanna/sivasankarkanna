//
//  ExtensionToStructFile.swift
//  TestSampleCasses
//
//  Created by Apple on 25/06/21.
//  Copyright © 2021 Apple. All rights reserved.
//

import Foundation

struct SampleStruct {
    
}

