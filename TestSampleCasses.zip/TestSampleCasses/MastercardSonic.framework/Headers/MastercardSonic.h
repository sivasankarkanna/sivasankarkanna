//
//  MastercardSonic.h
//  MastercardSonic
//
//  Created by Mastercard on 06/03/20.
//  Copyright © 2020 Mastercard. All rights reserved.
//
		

#import <Foundation/Foundation.h>

//! Project version number for MastercardSonic.
FOUNDATION_EXPORT double MastercardSonicVersionNumber;

//! Project version string for MastercardSonic.
FOUNDATION_EXPORT const unsigned char MastercardSonicVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MastercardSonic/PublicHeader.h>


